﻿using System;

namespace GloboTicket.TicketManagement.Application.Features.Events
{
    public class CategoryDto
    {
        public Guid Id { get; set; }

        public string Name { get; set; }
    }
}