﻿namespace GloboTicket.TicketManagement.Application.Contracts
{
    public interface ILoggedInUserService
    {
        public string UserId { get; }
    }
}
