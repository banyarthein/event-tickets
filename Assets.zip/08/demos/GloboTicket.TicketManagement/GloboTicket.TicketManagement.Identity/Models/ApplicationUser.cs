﻿using Microsoft.AspNetCore.Identity;

namespace GloboTicket.TicketManagement.Identity.Models
{
    public class ApplicationUser : IdentityUser
    {
  
    }
}
