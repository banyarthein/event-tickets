﻿namespace GloboTicket.TicketManagement.App.ViewModels
{
    public class CategoryViewModel
    {
        public Guid CategoryId { get; set; }
        public string Name { get; set; } = string.Empty;
    }
}
